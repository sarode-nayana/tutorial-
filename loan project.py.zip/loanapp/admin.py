from django.contrib import admin
from loanapp.models import users,loanappdb
# Register your models here.
admin.site.register(users)
admin.site.register(loanappdb)