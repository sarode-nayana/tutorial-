from django.db import models

# Create your models here.
class users(models.Model):
    email=models.CharField(max_length=30,unique=True)
    password=models.CharField(max_length=30)

class loanappdb(models.Model):
    name = models.CharField(max_length=30)
    mobileno = models.CharField(max_length=12)
    email = models.CharField(max_length=30)
    mstatus = models.CharField(max_length=10)
    loantype = models.CharField(max_length=30)
    amount = models.CharField(max_length=30)
    income = models.CharField(max_length=30)
    address = models.TextField()
    city = models.CharField(max_length=30)
    pincode = models.CharField(max_length=10)
    aor=models.IntegerField(default=1)