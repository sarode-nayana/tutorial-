from django.contrib import admin
from django.urls import path
from loanapp import views
urlpatterns = [
    path("",views.index),
    path('index', views.index),
    path('signup', views.signup),
path('login', views.login),
path('services', views.services),
path('contact', views.contact),
path('about', views.about),
path('loan_application', views.loanapplication),
path("administrator",views.admin)
]