from django.shortcuts import render,HttpResponse
from loanapp.models import users,loanappdb
gname=""
# Create your views here.
def index(request):
    qw = users.objects.all()
    #users.objects.all().delete()
    #loanappdb.objects.all().delete()
    for i in qw:
        print(i.email,i.password)
    return render(request,"index.html")

def signup(request):
    if request.method=="POST":
        email = request.POST.get("email")
        password = request.POST.get("psw")
        reppassword = request.POST.get("psw-repeat")
        print(email,password,reppassword)
        if(password==reppassword):
            varuser=users(email=email,password=password)
            varuser.save()
            return HttpResponse("Sign Up Successfully")
        else:
            return HttpResponse("Password fields do not match")
    return render(request,"signup.html")

def login(request):
    global gname
    if request.method=="POST":
        email = request.POST.get("email")
        password = request.POST.get("psw")
        print(email,password)
        try:
            dbpass=users.objects.get(email=email)
            print(dbpass.password)
            if password==dbpass.password:
                gname=email
                print(gname)
                return HttpResponse("Login Successfully")
            else:
                return HttpResponse("Invalid credentials")
        except:
            return HttpResponse("No such user exists, Sign in first")
    return render(request,"login.html")
def services(request):
    return render(request,"services.html")
def contact(request):
    return render(request,"contact.html")
def about(request):
    return render(request,"about.html")

def loanapplication(request):
    if request.method=="POST":
        name = request.POST.get("name")
        mobileno = request.POST.get("mobile_number")
        email = request.POST.get("email")
        mstatus = request.POST.get("mstatus")
        loantype = request.POST.get("loan_type")
        amount = request.POST.get("required_amount")
        income = request.POST.get("Annual_Income")
        address = request.POST.get("address")
        city = request.POST.get("city")
        pincode = request.POST.get("pincode")

        varloanapp=loanappdb(name=name,mobileno=mobileno,email=email,mstatus=mstatus,loantype=loantype,amount=amount,income=income,address=address,city=city,pincode=pincode,aor=1)
        varloanapp.save()

    qw = loanappdb.objects.filter(email=gname)
    context={"objlist":qw,"ema":gname}
    return render(request,"loan_application.html",context)

def admin(request):
    if request.method == "POST":
        id=request.POST.get("id")
        aor=request.POST.get("aor")
        qw=loanappdb.objects.get(id=id)
        qw.aor=aor
        qw.save()
    #loanappdb.objects.all().delete()
    if gname=="admin@gmail.com":
        qw=loanappdb.objects.all()
        context={"objlist":qw}
        return render(request,"admin.html",context)
    return HttpResponse("You don't have admin privilages")
